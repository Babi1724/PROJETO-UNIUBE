<?
    echo "nome: ".$_POST['Nome'];
    echo '<br';
    echo "Idade: ".$_POST['Idade'];
    echo '<hr';

    print(.$POST['Nome']);
?>