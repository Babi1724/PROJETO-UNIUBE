<html>
    <title>Primeira Aula</title>
    <head></head>

    <body>
        <form method="post" action="teste.php">
            Nome: <input type="text" name="nome"><br>
            <br>
            Idade: <input type="text" name="idade"><br>
            <br>
            <input type="submit" value="enviar">
        </form>
    </body>
</html>